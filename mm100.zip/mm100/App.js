import * as React from 'react';
import { Text, View, StyleSheet, TouchableHighlight, ScrollView, Image } from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import { createAppContainer, createBottomTabNavigator, createSwitchNavigator, createDrawerNavigator, } from 'react-navigation';

import AcademiaScreen from './components/MainScreens/AcademiaScreen';
import AthleticsScreen from './components/MainScreens/AthleticsScreen';
import ArtsScreen from './components/MainScreens/ArtsScreen';
import MiscellaneousScreen from './components/MainScreens/MiscellaneousScreen';
import HomeScreen from './components/MainScreens/HomeScreen';
import LoadingScreen from './components/LoadingScreen'; //initial viewing screen
import SettingScreen from './components/SpecialScreens/SettingsScreen.js';
import Calendar from './components/SpecialScreens/Calendar.js';
import SearchBar from './components/SpecialScreens/SearchBar.js';
import MoreLinks from './components/SpecialScreens/MoreLinks.js';

const myStyles = require('./assets/styles.js'); //styles class found in different file


  
//main driver class
export default class MountieMobileApp extends React.Component {
  render() {
    return (
      <View style={styles.container}>   
        <FullAppContainer />
      </View> 
    );
  }
}



//bottom navigation tab configuration
const TabNavigator = createBottomTabNavigator(
  {
    Academia: AcademiaScreen,
    Arts: ArtsScreen,
    Home: HomeScreen,
    Athletics: AthleticsScreen,
    Misc: MiscellaneousScreen
  },
  {
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, horizontal, tintColor }) => {
        const { routeName } = navigation.state;
        if (routeName === 'Academia') {
           const image = focused
        ? require('./assets/icons/BottomTabNavigator/books-stack-of-three-selected.png')
        : require('./assets/icons/BottomTabNavigator/books-stack-of-three.png')
          return (
            <Image 
              source={image} 
              style={{ height: 25, width: 25 }} 
            />
          );
        } 
        else if (routeName === 'Arts') {
          const image = focused
        ? require('./assets/icons/BottomTabNavigator/music-note-selected.png')
        : require('./assets/icons/BottomTabNavigator/music-note.png')
          return (
            <Image 
              source={image} 
              style={{ height: 25, width: 25 }} 
            />
          );
        }
        else if (routeName === 'Home') {
         const image = focused
        ? require('./assets/icons/BottomTabNavigator/home-icon-selected.png')
        : require('./assets/icons/BottomTabNavigator/home-icon.png')
          return (
            <Image 
              source={image} 
              style={{ height: 25, width: 25 }} 
            />
          );
        } 
        else if (routeName === 'Athletics') { 
         const image = focused
        ? require('./assets/icons/BottomTabNavigator/rugby-ball-selected.png')
        : require('./assets/icons/BottomTabNavigator/rugby-ball.png')
          return (
            <Image 
              source={image} 
              style={{ height: 25, width: 25 }} 
            />
          );
        } 
        else if (routeName === 'Misc') {
         const image = focused
        ? require('./assets/icons/BottomTabNavigator/more-selected.png')
        : require('./assets/icons/BottomTabNavigator/more.png')
          return (
            <Image 
              source={image} 
              style={{ height: 25, width: 25 }} 
            />
          );
        }
        // You can return any component that you like here!
        return (
          <Image 
            source={require('./assets/icons/BottomTabNavigator/books-stack-of-three.png')} 
            style={{ height: 25, width: 25 }} 
          />
        );
      },
    }),
    tabBarOptions: {
      activeTintColor: '#142EEF', //'#0e3eee' is the former blue color used
      inactiveTintColor: 'black',
      activeBackgroundColor: 'transparent', //#ccddff is the blue tint on bottom tab navigator
      inactiveBackgroundColor: 'transparent',
    },
    navigationOptions: { header: null, 
      drawerLabel: 'Events',
    drawerIcon: ({ tintColor }) => (
      <Image
        source={require('./assets/icons/mountie-head.png')}
        style={[styles.icon, { tintColor: tintColor,width:30,height:30 }]}
      />
    ),
  },
    initialRouteName: 'Home',
    adaptive: 'true',
  }
);

const AppNavigator = createDrawerNavigator(
  {
    Events: TabNavigator,
    SearchBar: SearchBar,
    Calendar: Calendar,
    Settings: SettingScreen,
    MoreLinks: MoreLinks,
  },
  { 
    initialRouteName: 'Events',
    drawerPosition: 'right',
    contentOptions: {
      activeTintColor: '#142EEF',
      inactiveTintColor: 'black',
    }
  }
);

//Loading screen implemented here with the tabNavigator
const FULLNavigator = createSwitchNavigator({
  Loading: LoadingScreen,
  App: AppNavigator
});

const FullAppContainer = createAppContainer( FULLNavigator ); //must be done in version 3 of React Navigation




const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: getStatusBarHeight(),
    backgroundColor: '#ecf0f1'
  },
});


