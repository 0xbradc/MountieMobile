import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  Button,
  Image,
  TouchableOpacity,
  Switch,
} from 'react-native';
import Header from '../Header.js';
import ModalDropdown from 'react-native-modal-dropdown';
//import firebase from 'react-native-firebase';
//import type { Notification } from 'react-native-firebase';
const myStyles = require('../../assets/styles.js');

  
export default class Notifications extends React.Component {
  static navigationOptions = { header: null };

  state = {
    currentCategory: 'Click to select a category...',
  };

  passCategory = value => {
    this.setState({ currentCategory: value });
  };

  check(index){
    if (index == 0)
      return "Athletics";
    else if (index == 1)
      return "Academics";
    else if (index == 2)
      return "Arts";
    else if (index == 3)
      return "Miscellaneous";
    else return "Click to select a category...";
  }


  render() {
    return (
      <View style={styles.container}>
        <Header backButton={ true } />
        <View>
          <ScrollView>
            <View style={{ flexDirection: 'row' }}>
              <View>
                <ModalDropdown
                  options={['Athletics', 'Academics', 'Arts', 'Miscellaneous']}
                  style={{ padding: 10, backgroundColor: '#ecf0f1' }}
                  dropdownTextStyle={{ fontSize: 20, color: 'black' }}
                  onSelect={ this.passCategory } >
                  <View style={{ flexDirection: 'row', paddingRight: 30, }}>
                    <Text style={ styles.modalText }>{ this.check(this.state.currentCategory) }</Text>
                    <Image source={require('../../assets/icons/down-arrow.png')}
                    style={{ height: 20, width: 20, justifyContent: 'center', paddingTop: 10 }} />
                  </View>
                </ModalDropdown>
              </View>
            </View>
            <View style={{ paddingBottom: 90 }}>
              <ModalDirectory eventCategory={ this.state.currentCategory } />
            </View>
          </ScrollView>
        </View>
      </View>
    );
  }
}

class ModalDirectory extends React.Component {
  constructor() {
    super();

    this.state = {
      notificationsArray: [
        true,
        true,
        true,
        true,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        false, //athletics ends
        true,
        false,
        false,
        false, //academia ends
        true,
        false,
        false,
        false,
        false, //arts ends
        false,
        false,
        true, //misc ends
      ],
    };
  }


  //method for the on/off switch changing its own element to the opposite
  toggleAny = (index, topic) => {
    let nueva = this.state.notificationsArray.slice(); //creates clone of the state
    nueva[index] = !nueva[index];
    /*
    if(nueva[index])
    {
      firebase.messaging().subscribeToTopic(topic);
    }
    else {
      firebase.messaging().unsubscribeFromTopic(topic);
    }*/
    this.setState({ notificationsArray: nueva });
  };

  //method used for exporting the array to the FIREBASE
  exporting = () => {
    return this.state.notificationsArray;
  };

  //this.props.eventCategory is returning the INDEX of the selected item in the ModalDropdown
  render() {
    var event0 = [
      "Baseball",
      "Basketball",
      "Bowling",
      "Cross Country",
      "Football",
      "Golf",
      "Track and Field",
      "Tennis",
      "Volleyball",
      "Wrestling",
      "Soccer",
      "Cheer/Competitive Dance",
    ];
      var event1 = [
        "Tutoring",
        "ACT",
        "SAT",
        "Assembly",
      ];

      var event2 = [
        "Orchestra",
        "Band",
        "Drama",
        "Choir",
        "Theatre Dance",
      ];

      var event3 = [
        "School Dance",
        "Pep Rally",
        "Club Meeting",
      ];


    if (this.props.eventCategory == 0) {
      return (
            <View>{this.list(event0, 0)}</View>
      );
    }

    else if (this.props.eventCategory == 1) {
      return (
            <View>{this.list(event1, event0.length)}</View>
      );
    }

    else if (this.props.eventCategory == 2) {
      return (
            <View>{this.list(event2, event0.length+event1.length)}</View>
      );

    }

    else if (this.props.eventCategory == 3) {
      return (
        <View>{this.list(event3, event0.length+event1.length+event2.length)}</View>
      );
    }
    else {
      return (
        <Text style={{ fontSize: 20, textAlign: 'center', padding: 20 }}>
          Please Select a notifications category to adjust settings.
        </Text>
      );
        }
      }
      list = (events, num) =>
      {
         return <View>{events.map((item, key)=> {
           return (
          <View style={{ backgroundColor: 'white' }}>
            <View
              style={ styles.containerText }>
              <Text key = {key}>
                {item}
              </Text>
              <Switch
                value={this.state.notificationsArray[key+num]}
                trackColor = {{false: null, true: 'blue'}}
                onValueChange={index => this.toggleAny(key + num, item)}
              />
            </View>
          </View>
        )
        })}
        </View>
      }

    }



const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 0,
    backgroundColor: '#ecf0f1',
    padding: 0,
  },
  modalText: {
    color: 'blue',
    fontSize: 20,
    fontWeight: 'bold',
    paddingRight: 20,
  },
  containerText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
  },
});


