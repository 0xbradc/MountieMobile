import * as React from 'react';
import { Text, View, StyleSheet, TouchableHighlight, ScrollView, Image } from 'react-native';
import EventList from '../EventList.js';
import { createStackNavigator } from 'react-navigation-stack';
import InfoScreen from '../SpecialScreens/InfoScreen.js';
import Header from '../Header.js';


class AthleticsScreen extends React.Component {
  static navigationOptions = { header: null 
  };
  
  render() {    
    return (
      <View style={styles.container}>
        <Header menuButton = { true }/>
        
        <ScrollView>
          <Text style = {{borderBottomWidth: 1, paddingBottom: 10, fontSize: 20, textAlign: 'center', fontWeight: 'bold'}}>
            Athletic Events
          </Text> 
          <EventList eventCategory="athletics"/>
        </ScrollView>
      </View>
    );
  }
}


export default createStackNavigator(
  {
    Default: AthleticsScreen,
    Information: InfoScreen
  },
  { initialRouteName: 'Default'}
);



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: 0,
    backgroundColor: '#ecf0f1',
    padding: 0,
  }
});


